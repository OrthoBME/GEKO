function DATA = GEKO_calc(rawpoints,filename)

%filename = 'AAA';
disp(['Below are the error codes for ', filename,'. If no codes exist, no errors occurred during data calculation.']);
if exist('rawpoints')
    
    %% Medial Tibial Plateau Width
    if isfield(rawpoints,'tibplateau')
        if size(rawpoints.tibplateau) == [2,2]
            TibialPlateauWidth = pdist(rawpoints.tibplateau,'euclidean');
        else 
            TibialPlateauWidth = 999999999;
            disp('Measurement of tibial plateau contains too few or too many points.');
        end
    else
        TibialPlateauWidth = 999999999;
        disp('Measurement of tibial plateau does not exist.');
    end
    
    %% Total Cartilage Degeneration Including Proteoglycan Loss
    if isfield(rawpoints,'totalcartdegen')
        if size(rawpoints.totalcartdegen) == [2,2]
            TotalCartilageDegenerationWidth_Pixel = pdist(rawpoints.totalcartdegen,'euclidean');
            if isfield(rawpoints,'tibplateau')
                if size(rawpoints.tibplateau) == [2,2]
                    TotalCartilageDegenerationWidth_Perc = TotalCartilageDegenerationWidth_Pixel/TibialPlateauWidth;
                else
                    TotalCartilageDegenerationWidth_Perc = 999999999;
                end
            else
                TotalCartilageDegenerationWidth_Perc = 999999999;
            end
        elseif length(rawpoints.totalcartdegen(:,1)) > 2
            TotalCartilageDegenerationWidth_Pixel = 999999999;
            TotalCartilageDegenerationWidth_Perc = 999999999;
            disp('Measurement of total cartilage degeneration contains too many points.');
        else
            TotalCartilageDegenerationWidth_Pixel = 0;
            TotalCartilageDegenerationWidth_Perc = 0;
        end
    else
        TotalCartilageDegenerationWidth_Pixel = 0;
        TotalCartilageDegenerationWidth_Perc = 0;
    end
    
    %% Cartilage Loss Width at the Surface, Based on Visual Measurement by the User
    if isfield(rawpoints,'cartilagelesionwidth')
        if size(rawpoints.cartilagelesionwidth) == [2,2]
            CartilageLossWidth_VisualMeasurement_Pixel = pdist(rawpoints.cartilagelesionwidth,'euclidean');
            if isfield(rawpoints,'tibplateau')
                if size(rawpoints.tibplateau) == [2,2]
                    CartilageLossWidth_VisualMeasurement_Perc = CartilageLossWidth_VisualMeasurement_Pixel/TibialPlateauWidth;
                else
                    CartilageLossWidth_VisualMeasurement_Perc = 999999999;
                end
            else
                CartilageLossWidth_VisualMeasurement_Perc = 999999999;
            end
        elseif length(rawpoints.cartilagelesionwidth(:,1)) > 2
            AAA = [rawpoints.cartilagelesionwidth(1,:);rawpoints.cartilagelesionwidth(length(rawpoints.cartilagelesionwidth(:,1)),:)];
            CartilageLossWidth_VisualMeasurement_Pixel = pdist(AAA,'euclidean');
            if isfield(rawpoints,'tibplateau')
                if size(rawpoints.tibplateau) == [2,2]
                    CartilageLossWidth_VisualMeasurement_Perc = CartilageLossWidth_VisualMeasurement_Pixel/TibialPlateauWidth;
                else
                    CartilageLossWidth_VisualMeasurement_Perc = 999999999;
                end
            else
                CartilageLossWidth_VisualMeasurement_Perc = 999999999;
            end
            clear AAA
        elseif length(rawpoints.cartilagelesionwidth(:,1)) == 0
            CartilageLossWidth_VisualMeasurement_Pixel = 0;
            CartilageLossWidth_VisualMeasurement_Perc = 0;
        else
            CartilageLossWidth_VisualMeasurement_Pixel = 999999999;
            CartilageLossWidth_VisualMeasurement_Perc = 999999999;
            disp('Error in the visual measurement of cartilage lesion width. Unexpected number of points.');
        end
    else
        CartilageLossWidth_VisualMeasurement_Pixel = 0;
        CartilageLossWidth_VisualMeasurement_Perc = 0;
    end
    
    %% Medial Joint Capsule Width
    if isfield(rawpoints,'jointcapsule')
        if length(rawpoints.jointcapsule) > 2
            Capsule_n = ceil(max(rawpoints.jointcapsule(:,1))); Capsule_m = ceil(max(rawpoints.jointcapsule(:,2)));
            MedialCapsule_unrotated = poly2mask(rawpoints.jointcapsule(:,1),rawpoints.jointcapsule(:,2),Capsule_m,Capsule_n);
            %MedialCapsule_unrotated = ReduceToOneArea(MedialCapsule);
            CapsuleStats = regionprops(MedialCapsule_unrotated,'Orientation');
            MedialCapsuleBW = imrotate(MedialCapsule_unrotated,-CapsuleStats.Orientation);
            CapsuleStart = min(find(sum(MedialCapsuleBW)>0));
            CapsuleEnd = max(find(sum(MedialCapsuleBW)>0));
            CapsuleAAA = CapsuleEnd - CapsuleStart;
            MedialCapsule_Trimmed = MedialCapsuleBW(:,CapsuleStart+(CapsuleAAA)*.1:CapsuleEnd-(CapsuleAAA)*.1); 
            MedialCapsuleWidth = mean(sum(MedialCapsule_Trimmed));
        else 
            MedialCapsuleWidth = 999999999;
            disp('Measurement of medial joint capsule contains too few or too many points.');
        end
    else
        MedialCapsuleWidth = 999999999;
        disp('Measurement of medial joint capsule does not exist.');
    end
    
    %% Measurement of Osteophyte Area (location and orientation are AFTER cartilage definition)
    if isfield(rawpoints,'osteophyte')
        if length(rawpoints.osteophyte(:,1)) > 2
            OsteophyteArea = polyarea(rawpoints.osteophyte(:,1),rawpoints.osteophyte(:,2));
            Osteo_n = ceil(max(rawpoints.osteophyte(:,1))); Osteo_m = ceil(max(rawpoints.osteophyte(:,2))); 
            OsteophyteBW_unrotated = poly2mask(rawpoints.osteophyte(:,1),rawpoints.osteophyte(:,2),Osteo_m,Osteo_n);
            OsteophyteBW_unrotated = ReduceToOneArea(OsteophyteBW_unrotated);
            OsteophyteStats = regionprops(OsteophyteBW_unrotated,'Orientation','Eccentricity');
            OsteophyteEccentricity = OsteophyteStats.Eccentricity;
            OsteophyteOrientation_unrotated = OsteophyteStats.Orientation;
        elseif length(rawpoints.osteophyte(:,1)) == 0
            OsteophyteArea = 0;
            OsteophyteEccentricity = 999999999;
            OsteophyteOrientation = 999999999;
        else 
            OsteophyteArea = 999999999;
            OsteophyteEccentricity = 999999999;
            OsteophyteOrientation = 999999999;
            disp('Measurement of osteophyte area contains too few points.');
        end
    else
        OsteophyteArea = 0;
        OsteophyteEccentricity = 999999999;
        OsteophyteOrientation = 999999999;
    end   
    
    %% Measurement of Cartilage Characteristics
    if isfield(rawpoints,'osteointerface')

        if isfield(rawpoints,'cartilagesurface')

            if length(rawpoints.osteointerface(:,1)) > 2
                
                if length(rawpoints.cartilagesurface(:,1)) >2
                    
                    % Create outline of the cartilage --
                    LastOsteointerfacePoint = rawpoints.osteointerface(length(rawpoints.osteointerface(:,1)),:);
                    FirstCartilageSurfacePoint = rawpoints.cartilagesurface(1,:);
                    LastCartilageSurfacePoint = rawpoints.cartilagesurface(length(rawpoints.cartilagesurface(:,1)),:);
                    FirstPointDist = pdist([FirstCartilageSurfacePoint;LastOsteointerfacePoint],'euclidean');
                    LastPointDist = pdist([LastCartilageSurfacePoint;LastOsteointerfacePoint],'euclidean');
                    clear counter
                    if FirstPointDist < LastPointDist
                        Cartilage = [rawpoints.osteointerface;rawpoints.cartilagesurface;rawpoints.osteointerface(1,:)];
                    else
                        counter = 1;
                        OsteointerfaceLength = length(rawpoints.osteointerface(:,1));
                        Cartilage = rawpoints.osteointerface;
                        for i = length(rawpoints.cartilagesurface(:,1)):-1:1
                            Cartilage(OsteointerfaceLength+counter,:) = rawpoints.cartilagesurface(i,:);
                            counter = counter+1;
                        end
                        Cartilage(OsteointerfaceLength+counter,:) = rawpoints.osteointerface(1,:);
                        clear counter
                    end

                    % Calculate Cartilage Area
                    CartilageArea = polyarea(Cartilage(:,1),Cartilage(:,2));
                    if exist('OsteophyteArea')
                        CartilageAreaLessOsteophyte = CartilageArea - OsteophyteArea;
                    else
                        CartilageAreaLessOsteophyte = CartilageArea;
                    end

                    % Orient Cartilage Area to Make it Flat and trim the left 10%
                    % and right 10%
                    n = ceil(max(Cartilage(:,1))); m = ceil(max(Cartilage(:,2))); %Do not clear n and m -- used later!
                    CartilageBW_unrotated = poly2mask(Cartilage(:,1),Cartilage(:,2),m,n);
                    CartilageBW_unrotated = ReduceToOneArea(CartilageBW_unrotated);
                    CartilageStats = regionprops(CartilageBW_unrotated,'Orientation');
                    if isfield(rawpoints,'osteophyte')
                        if length(rawpoints.osteophyte(:,1)) > 2
                            if CartilageStats.Orientation < 0
                                OsteophyteOrientation = (OsteophyteOrientation_unrotated+90) - CartilageStats.Orientation;
                            else
                                OsteophyteOrientation = OsteophyteOrientation_unrotated - CartilageStats.Orientation;
                            end
                        end
                    end
                    CartilageBW = imrotate(CartilageBW_unrotated,-CartilageStats.Orientation);
                    AAA = sum(CartilageBW);
                    id = find(AAA>0);
                    TibialPlateauWidth_FromCartilageArea = max(id) - min(id);
                    CartThicknessSum_Start = ceil(min(id) + TibialPlateauWidth_FromCartilageArea*.1);
                    CartThicknessSum_End = floor(max(id) - TibialPlateauWidth_FromCartilageArea*.1);
                    CartilageBW_Trimmed = CartilageBW(:,CartThicknessSum_Start:CartThicknessSum_End);
                    clear AAA id CartilageStats

                    % Find the average thickness of the cartilage, variability in
                    % cartilage thickness, maximum thickness, minimum thickness,
                    % and location of maximum and minimum thickness
                    ThicknessSum = sum(CartilageBW_Trimmed);
                    AverageCartilageThickness_Pixels = mean(ThicknessSum);
                    VariabilityInCartilageThickness_Pixels = var(ThicknessSum);
                    MaximumCartilageThickness_Pixels = max(ThicknessSum);
                    MinimumCartilageThickness_Pixels = min(ThicknessSum);
                    id_max = find(ThicknessSum == MaximumCartilageThickness_Pixels);
                    id_min = find(ThicknessSum == MinimumCartilageThickness_Pixels);
                    if length(id_max) > 1
                        LocationOfMaxCartilageThickness = (min(id_max)+TibialPlateauWidth_FromCartilageArea*.1)/TibialPlateauWidth_FromCartilageArea;
                    else
                        LocationOfMaxCartilageThickness = (id_max+TibialPlateauWidth_FromCartilageArea*.1)/TibialPlateauWidth_FromCartilageArea;
                    end
                    if length(id_min) > 1
                        LocationOfMinCartilageThickness = (min(id_min)+TibialPlateauWidth_FromCartilageArea*.1)/TibialPlateauWidth_FromCartilageArea;
                    else
                        LocationOfMinCartilageThickness = (id_min+TibialPlateauWidth_FromCartilageArea*.1)/TibialPlateauWidth_FromCartilageArea;
                    end
                    
                    % Bounding Box Above and Below
                    AAA = sum(CartilageBW_Trimmed');
                    id1 = find(AAA>0);
                    id2 = find(AAA == max(AAA));
                    if length(id2) > 1
                        id2 = round(median(id2),0);
                    end
                    CartilageBW_Top = CartilageBW_Trimmed(min(id1):id2,:);
                    CartilageBW_Bottom = CartilageBW_Trimmed(id2:max(id1),:);
                    CartilageBW_Top = ReduceToOneArea(CartilageBW_Top);
                    CBWTStats = regionprops(CartilageBW_Top,'Extent');
                    CartilageBW_Bottom = ReduceToOneArea(CartilageBW_Bottom);
                    CBWBStats = regionprops(CartilageBW_Bottom,'Extent');
                    PercOfCartilageInTopBoundingBox   = CBWTStats.Extent;
                    PercOfCartilageInBottomBoundingBox   = CBWBStats.Extent;
                    clear AAA

                    % Same concept as above, but for every 5th percentile
                    Z13_length = size(CartilageBW_Trimmed);
                    Z_Cartilage = CartilageBW_Trimmed(:,1:Z13_length(2));
                    Thickness_000 = sum(Z_Cartilage(:,1));
                    Thickness_005 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.05)));
                    Thickness_010 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.10)));
                    Thickness_015 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.15)));
                    Thickness_020 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.20)));
                    Thickness_025 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.25)));
                    Thickness_030 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.30)));
                    Thickness_035 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.35)));
                    Thickness_040 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.40)));
                    Thickness_045 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.45)));
                    Thickness_050 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.50)));
                    Thickness_055 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.55)));
                    Thickness_060 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.60)));
                    Thickness_065 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.65)));
                    Thickness_070 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.70)));
                    Thickness_075 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.75)));
                    Thickness_080 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.80)));
                    Thickness_085 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.85)));
                    Thickness_090 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.90)));
                    Thickness_095 = sum(Z_Cartilage(:,floor(Z13_length(2)*0.95)));
                    Thickness_100 = sum(Z_Cartilage(:,floor(Z13_length(2))));
                    
                    % Need to find Lesion Widths...
                    % Step 1, Create a Cartilage Lesion Object
                    if isfield(rawpoints,'cartilagelesionwidth')
                    
                        if length(rawpoints.cartilagelesionwidth(:,1)) >= 2
                            AAA = [rawpoints.cartilagelesionwidth(1,:);rawpoints.cartilagelesionwidth(length(rawpoints.cartilagelesionwidth(:,1)),:)];
                            XPoints = rawpoints.cartilagesurface(:,1);
                            YPoints = rawpoints.cartilagesurface(:,2);
                            DistanceFromFirstPoint = sqrt( ( AAA(1,1)-XPoints ).^2 + ( AAA(1,2)-YPoints).^2 );
                            DistanceFromLastPoint = sqrt( ( AAA(2,1)-XPoints ).^2 + ( AAA(2,2)-YPoints).^2 );    
                            FirstPointID = find(DistanceFromFirstPoint == min(DistanceFromFirstPoint));
                            LastPointID = find(DistanceFromLastPoint == min(DistanceFromLastPoint));
                            for i = 1:(max(LastPointID)-min(FirstPointID))
                                CartilageLesion(i,:) = rawpoints.cartilagesurface(min(FirstPointID)+(i-1),:);
                            end
                            CartilageLesion(length(CartilageLesion(:,1))+1,:) = rawpoints.cartilagesurface(min(FirstPointID),:);
                        else
                            CartilageLesion = 0;
                        end
                        
                    else
                        
                        CartilageLesion = 0;
                        TotalCartilageDamage = 0;
                        Z1_CartilageDamage = 0;
                        Z2_CartilageDamage = 0;
                        Z3_CartilageDamage = 0;
                        
                        Z1_DepthRatio_Midpoint = 0;
                        Z2_DepthRatio_Midpoint = 0;
                        Z3_DepthRatio_Midpoint = 0;
                        
                        Z000_DepthRatio = 0;
                        Z005_DepthRatio = 0;
                        Z010_DepthRatio = 0;
                        Z015_DepthRatio = 0;
                        Z020_DepthRatio = 0;
                        Z025_DepthRatio = 0;
                        Z030_DepthRatio = 0;
                        Z035_DepthRatio = 0;
                        Z040_DepthRatio = 0;
                        Z045_DepthRatio = 0;
                        Z050_DepthRatio = 0;
                        Z055_DepthRatio = 0;
                        Z060_DepthRatio = 0;
                        Z065_DepthRatio = 0;
                        Z070_DepthRatio = 0;
                        Z075_DepthRatio = 0;
                        Z080_DepthRatio = 0;
                        Z085_DepthRatio = 0;
                        Z090_DepthRatio = 0;
                        Z095_DepthRatio = 0;
                        Z100_DepthRatio = 0;
                        
                        D000_LossWidth = 0;
                        D005_LossWidth = 0;
                        D010_LossWidth = 0;
                        D015_LossWidth = 0;
                        D020_LossWidth = 0;
                        D025_LossWidth = 0;
                        D030_LossWidth = 0;
                        D035_LossWidth = 0;
                        D040_LossWidth = 0;
                        D045_LossWidth = 0;
                        D050_LossWidth = 0;
                        D055_LossWidth = 0;
                        D060_LossWidth = 0;
                        D065_LossWidth = 0;
                        D070_LossWidth = 0;
                        D075_LossWidth = 0;
                        D080_LossWidth = 0;
                        D085_LossWidth = 0;
                        D090_LossWidth = 0;
                        D095_LossWidth = 0;
                        D100_LossWidth = 0;
                    
                    end
                    
                    if CartilageLesion ~= 0
                        
                        % Orient the Cartilage Lesion Object
                        CartilageLesionBW_unrotated = poly2mask(CartilageLesion(:,1),CartilageLesion(:,2),m,n);
                        LabeledCartilage = zeros([m,n]);
                        LabeledCartilage(CartilageLesionBW_unrotated == 1) = 2;
                        LabeledCartilage(CartilageBW_unrotated == 1) = 1;
                        
                        LesionPlusCartilage = zeros([m,n]);
                        LesionPlusCartilage(CartilageLesionBW_unrotated == 1) = 1;
                        LesionPlusCartilage(CartilageBW_unrotated == 1) = 1;
                        
                        Slope = (CartilageLesion(length(CartilageLesion(:,2))-1,2)-CartilageLesion(1,2)) / (CartilageLesion(length(CartilageLesion(:,1))-1,1)-CartilageLesion(1,1));
                        LesionOrientation = atan(Slope)*180/pi();
                        
                        CartilageLesionBW_rotated = imrotate(CartilageLesionBW_unrotated,LesionOrientation);
                        LabeledCartilage_rotated = imrotate(LabeledCartilage,LesionOrientation);
                        LesionPlusCartilage_rotated = imrotate(LesionPlusCartilage,LesionOrientation);
                        LabeledCartilage_rotated_RGB = label2rgb(LabeledCartilage_rotated);
                    
                        % Cut the Cartilage Into Z1, Z2, and Z3 where Z1 is the
                        % edge of the joint, Z2 is the middle of the tibial plateau, and Z3
                        % is the interior of the joint
                        % ***Check this against Gerwin Definitions
                        LesionPlusCartilage_ColSum = sum(LesionPlusCartilage_rotated);
                        id = find(LesionPlusCartilage_ColSum>0);
                        LesionPlusCartilageWidth = max(id) - min(id);
                        LesionPlusCartilageTrimmed_Start = ceil(min(id) + LesionPlusCartilageWidth*.1);
                        LesionPlusCartilageTrimmed_End = floor(max(id) - LesionPlusCartilageWidth*.1);
                        LesionPlusCartilageTrimmed = LesionPlusCartilage_rotated(:,LesionPlusCartilageTrimmed_Start:LesionPlusCartilageTrimmed_End);
                        CartilageLesionTrimmed = CartilageLesionBW_rotated(:,LesionPlusCartilageTrimmed_Start:LesionPlusCartilageTrimmed_End);
                        clear id                        
                        
                        Z13_length = size(LesionPlusCartilageTrimmed);
                        Z23_line = round(Z13_length(2)*.333,0);
                        Z12_line = round(Z13_length(2)*.666,0);
                        TotalCartilageDamage = sum(sum(CartilageLesionTrimmed(:,1:Z13_length(2)))) / ( sum(sum(CartilageLesionTrimmed(:,1:Z13_length(2)))) + sum(sum(LesionPlusCartilageTrimmed(:,1:Z13_length(2)))) );
                        Z1_CartilageDamage = sum(sum(CartilageLesionTrimmed(:,Z12_line:Z13_length(2)))) / ( sum(sum(CartilageLesionTrimmed(:,Z12_line:Z13_length(2)))) + sum(sum(LesionPlusCartilageTrimmed(:,Z12_line:Z13_length(2)))) );
                        Z2_CartilageDamage = sum(sum(CartilageLesionTrimmed(:,Z23_line:Z12_line))) / ( sum(sum(CartilageLesionTrimmed(:,Z23_line:Z12_line))) + sum(sum(LesionPlusCartilageTrimmed(:,Z23_line:Z12_line))) );
                        Z3_CartilageDamage = sum(sum(CartilageLesionTrimmed(:,1:Z23_line))) / ( sum(sum(CartilageLesionTrimmed(:,1:Z23_line)))+ sum(sum(LesionPlusCartilageTrimmed(:,1:Z23_line))) );

                        % Calculate Depth Ratios
                        Z1_Location = Z12_line+floor( (Z13_length(2)-Z12_line)/2 );
                        Z1_DepthRatio_Midpoint = sum(CartilageLesionTrimmed(:,Z1_Location)) / sum(LesionPlusCartilageTrimmed(:,Z1_Location));
                        Z2_Location = Z23_line+floor( (Z12_line-Z23_line)/2 );
                        Z2_DepthRatio_Midpoint = sum(CartilageLesionTrimmed(:,Z2_Location)) / sum(LesionPlusCartilageTrimmed(:,Z2_Location));
                        Z3_Location = 1+floor( (Z23_line-1)/2 );
                        Z3_DepthRatio_Midpoint  = sum(CartilageLesionTrimmed(:,Z3_Location)) / sum(LesionPlusCartilageTrimmed(:,Z3_Location));
                                                
                        Z000_DepthRatio = sum(CartilageLesionTrimmed(:,1)) / sum(LesionPlusCartilageTrimmed(:,1));
                        Z005_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.05))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.05)));
                        Z010_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.10))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.10)));
                        Z015_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.15))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.15)));
                        Z020_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.20))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.20)));
                        Z025_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.25))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.25)));
                        Z030_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.30))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.30)));
                        Z035_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.35))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.35)));
                        Z040_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.40))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.40)));
                        Z045_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.45))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.45)));
                        Z050_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.50))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.50)));
                        Z055_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.55))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.55)));
                        Z060_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.60))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.60)));
                        Z065_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.65))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.65)));
                        Z070_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.70))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.70)));
                        Z075_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.75))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.75)));
                        Z080_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.80))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.80)));
                        Z085_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.85))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.85)));
                        Z090_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.90))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.90)));
                        Z095_DepthRatio = sum(CartilageLesionTrimmed(:,ceil(Z13_length(2)*0.95))) / sum(LesionPlusCartilageTrimmed(:,ceil(Z13_length(2)*0.95)));
                        Z100_DepthRatio = sum(CartilageLesionTrimmed(:,Z13_length(2)-1)) / sum(LesionPlusCartilageTrimmed(:,Z13_length(2)-1));
                        
                        % Focus in on Lesion To Calculate Loss Width Ratios                        
                        Lesion_ColumnSum = sum(CartilageLesionTrimmed);
                        StartOfLesion_Column = min(find(Lesion_ColumnSum > 0));
                        EndOfLesion_Column = max(find(Lesion_ColumnSum > 0));
                        
                        LesionPlusCartilageTrimmed_InLesionAreaOnly = LesionPlusCartilageTrimmed(:,StartOfLesion_Column:EndOfLesion_Column);
                        FindingMinThicknessForDepthCalc = sum(LesionPlusCartilageTrimmed_InLesionAreaOnly);
                        id_MinThicknessForDepthCalc = min(find(FindingMinThicknessForDepthCalc == min(FindingMinThicknessForDepthCalc)));
                        
                        FindingTopAndBottomForDepthCalc = LesionPlusCartilageTrimmed(:,StartOfLesion_Column+id_MinThicknessForDepthCalc);
                        TopOfLesion_Row = min(find(FindingTopAndBottomForDepthCalc > 0));
                        OsteoChondralInterfaceForDepthCalc_Row = max(find(FindingTopAndBottomForDepthCalc > 0));
                        
                        CartilageLesionTrimmed_ForDepthCalc = CartilageLesionTrimmed(TopOfLesion_Row:OsteoChondralInterfaceForDepthCalc_Row,:);
                        LesionPlusCartilageTrimmed_ForDepthCalc = LesionPlusCartilageTrimmed(TopOfLesion_Row:OsteoChondralInterfaceForDepthCalc_Row,:);
                       
                        CartilageLesionTrimmed_ForDepthCalc_Transformed = CartilageLesionTrimmed_ForDepthCalc';
                        LesionPlusCartilageTrimmed_ForDepthCalc_Transformed = LesionPlusCartilageTrimmed_ForDepthCalc';
                        DepthSize = size(CartilageLesionTrimmed_ForDepthCalc_Transformed);
                        D000_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,1)) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,1));
                        D005_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.05))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.05)));
                        D010_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.10))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.10)));
                        D015_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.15))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.15)));
                        D020_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.20))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.20)));
                        D025_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.25))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.25)));
                        D030_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.30))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.30)));
                        D035_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.35))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.35)));
                        D040_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.40))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.40)));
                        D045_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.45))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.45)));
                        D050_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.50))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.50)));
                        D055_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.55))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.55)));
                        D060_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.60))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.60)));
                        D065_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.65))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.65)));
                        D070_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.70))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.70)));
                        D075_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.75))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.75)));
                        D080_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.80))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.80)));
                        D085_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.85))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.85)));
                        D090_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.90))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.90)));
                        D095_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.95))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,ceil(DepthSize(2)*0.95)));
                        D100_LossWidth = sum(CartilageLesionTrimmed_ForDepthCalc_Transformed(:,DepthSize(2))) / sum(LesionPlusCartilageTrimmed_ForDepthCalc_Transformed(:,DepthSize(2)));
                    
                    else
                        
                        TotalCartilageDamage = 0;
                        Z1_CartilageDamage = 0;
                        Z2_CartilageDamage = 0;
                        Z3_CartilageDamage = 0;
                        
                        Z1_DepthRatio_Midpoint = 0;
                        Z2_DepthRatio_Midpoint = 0;
                        Z3_DepthRatio_Midpoint = 0;
                        
                        Z000_DepthRatio = 0;
                        Z005_DepthRatio = 0;
                        Z010_DepthRatio = 0;
                        Z015_DepthRatio = 0;
                        Z020_DepthRatio = 0;
                        Z025_DepthRatio = 0;
                        Z030_DepthRatio = 0;
                        Z035_DepthRatio = 0;
                        Z040_DepthRatio = 0;
                        Z045_DepthRatio = 0;
                        Z050_DepthRatio = 0;
                        Z055_DepthRatio = 0;
                        Z060_DepthRatio = 0;
                        Z065_DepthRatio = 0;
                        Z070_DepthRatio = 0;
                        Z075_DepthRatio = 0;
                        Z080_DepthRatio = 0;
                        Z085_DepthRatio = 0;
                        Z090_DepthRatio = 0;
                        Z095_DepthRatio = 0;
                        Z100_DepthRatio = 0;
                        
                        D000_LossWidth = 0;
                        D005_LossWidth = 0;
                        D010_LossWidth = 0;
                        D015_LossWidth = 0;
                        D020_LossWidth = 0;
                        D025_LossWidth = 0;
                        D030_LossWidth = 0;
                        D035_LossWidth = 0;
                        D040_LossWidth = 0;
                        D045_LossWidth = 0;
                        D050_LossWidth = 0;
                        D055_LossWidth = 0;
                        D060_LossWidth = 0;
                        D065_LossWidth = 0;
                        D070_LossWidth = 0;
                        D075_LossWidth = 0;
                        D080_LossWidth = 0;
                        D085_LossWidth = 0;
                        D090_LossWidth = 0;
                        D095_LossWidth = 0;
                        D100_LossWidth = 0;
                    
                    end
                    
                else
                    
                    CartilageArea = 999999999;
                    CartilageAreaLessOsteophyte = 999999999;
                    TibialPlateauWidth_FromCartilageArea  = 999999999;
                    AverageCartilageThickness_Pixels = 999999999; 
                    VariabilityInCartilageThickness_Pixels  = 999999999;
                    MaximumCartilageThickness_Pixels = 999999999;
                    MinimumCartilageThickness_Pixels = 999999999;
                    LocationOfMaxCartilageThickness = 999999999;  %As Percentage of Medial Tibial Plateau Width
                    LocationOfMinCartilageThickness = 999999999;  %As Percentage of Medial Tibial Plateau Width
                    PercOfCartilageInTopBoundingBox = 999999999;  %In Other Words - CartilageLesion_ViaExtent
                    PercOfCartilageInBottomBoundingBox = 999999999;  %In Other Words - SubchondralBoneOssification_ViaExtent
                    
                    Thickness_000 = 999999999;
                    Thickness_005 = 999999999;
                    Thickness_010 = 999999999;
                    Thickness_015 = 999999999;
                    Thickness_020 = 999999999;
                    Thickness_025 = 999999999;
                    Thickness_030 = 999999999;
                    Thickness_035 = 999999999;
                    Thickness_040 = 999999999;
                    Thickness_045 = 999999999;
                    Thickness_050 = 999999999;
                    Thickness_055 = 999999999;
                    Thickness_060 = 999999999;
                    Thickness_065 = 999999999;
                    Thickness_070 = 999999999;
                    Thickness_075 = 999999999;
                    Thickness_080 = 999999999;
                    Thickness_085 = 999999999;
                    Thickness_090 = 999999999;
                    Thickness_095 = 999999999;
                    Thickness_100 = 999999999;
                    
                    TotalCartilageDamage = 999999999;
                    Z1_CartilageDamage = 999999999;
                    Z2_CartilageDamage = 999999999;
                    Z3_CartilageDamage = 999999999;
                    
                    Z1_DepthRatio_Midpoint = 999999999;
                    Z2_DepthRatio_Midpoint = 999999999;
                    Z3_DepthRatio_Midpoint = 999999999;
                    
                    Z000_DepthRatio = 999999999;
                    Z005_DepthRatio = 999999999;
                    Z010_DepthRatio = 999999999;
                    Z015_DepthRatio = 999999999;
                    Z020_DepthRatio = 999999999;
                    Z025_DepthRatio = 999999999;
                    Z030_DepthRatio = 999999999;
                    Z035_DepthRatio = 999999999;
                    Z040_DepthRatio = 999999999;
                    Z045_DepthRatio = 999999999;
                    Z050_DepthRatio = 999999999;
                    Z055_DepthRatio = 999999999;
                    Z060_DepthRatio = 999999999;
                    Z065_DepthRatio = 999999999;
                    Z070_DepthRatio = 999999999;
                    Z075_DepthRatio = 999999999;
                    Z080_DepthRatio = 999999999;
                    Z085_DepthRatio = 999999999;
                    Z090_DepthRatio = 999999999;
                    Z095_DepthRatio = 999999999;
                    Z100_DepthRatio = 999999999;
                    
                    D000_LossWidth = 999999999;
                    D005_LossWidth = 999999999;
                    D010_LossWidth = 999999999;
                    D015_LossWidth = 999999999;
                    D020_LossWidth = 999999999;
                    D025_LossWidth = 999999999;
                    D030_LossWidth = 999999999;
                    D035_LossWidth = 999999999;
                    D040_LossWidth = 999999999;
                    D045_LossWidth = 999999999;
                    D050_LossWidth = 999999999;
                    D055_LossWidth = 999999999;
                    D060_LossWidth = 999999999;
                    D065_LossWidth = 999999999;
                    D070_LossWidth = 999999999;
                    D075_LossWidth = 999999999;
                    D080_LossWidth = 999999999;
                    D085_LossWidth = 999999999;
                    D090_LossWidth = 999999999;
                    D095_LossWidth = 999999999;
                    D100_LossWidth = 999999999;
                    disp('Measurement of cartilage surface contains too few points.');
                end
                
            else
                %****Add catches for calculated variables here
                CartilageArea = 999999999;
                CartilageAreaLessOsteophyte = 999999999;
                TibialPlateauWidth_FromCartilageArea  = 999999999;
                AverageCartilageThickness_Pixels = 999999999;
                VariabilityInCartilageThickness_Pixels  = 999999999;
                MaximumCartilageThickness_Pixels = 999999999;
                MinimumCartilageThickness_Pixels = 999999999;
                LocationOfMaxCartilageThickness = 999999999;  %As Percentage of Medial Tibial Plateau Width
                LocationOfMinCartilageThickness = 999999999;  %As Percentage of Medial Tibial Plateau Width
                PercOfCartilageInTopBoundingBox = 999999999;  %In Other Words - CartilageLesion_ViaExtent
                PercOfCartilageInBottomBoundingBox = 999999999;  %In Other Words - SubchondralBoneOssification_ViaExtent
                
                Thickness_000 = 999999999;
                Thickness_005 = 999999999;
                Thickness_010 = 999999999;
                Thickness_015 = 999999999;
                Thickness_020 = 999999999;
                Thickness_025 = 999999999;
                Thickness_030 = 999999999;
                Thickness_035 = 999999999;
                Thickness_040 = 999999999;
                Thickness_045 = 999999999;
                Thickness_050 = 999999999;
                Thickness_055 = 999999999;
                Thickness_060 = 999999999;
                Thickness_065 = 999999999;
                Thickness_070 = 999999999;
                Thickness_075 = 999999999;
                Thickness_080 = 999999999;
                Thickness_085 = 999999999;
                Thickness_090 = 999999999;
                Thickness_095 = 999999999;
                Thickness_100 = 999999999;
                
                TotalCartilageDamage = 999999999;
                Z1_CartilageDamage = 999999999;
                Z2_CartilageDamage = 999999999;
                Z3_CartilageDamage = 999999999;
                    
                Z1_DepthRatio_Midpoint = 999999999;
                Z2_DepthRatio_Midpoint = 999999999;
                Z3_DepthRatio_Midpoint = 999999999;
                
                Z000_DepthRatio = 999999999;
                Z005_DepthRatio = 999999999;
                Z010_DepthRatio = 999999999;
                Z015_DepthRatio = 999999999;
                Z020_DepthRatio = 999999999;
                Z025_DepthRatio = 999999999;
                Z030_DepthRatio = 999999999;
                Z035_DepthRatio = 999999999;
                Z040_DepthRatio = 999999999;
                Z045_DepthRatio = 999999999;
                Z050_DepthRatio = 999999999;
                Z055_DepthRatio = 999999999;
                Z060_DepthRatio = 999999999;
                Z065_DepthRatio = 999999999;
                Z070_DepthRatio = 999999999;
                Z075_DepthRatio = 999999999;
                Z080_DepthRatio = 999999999;
                Z085_DepthRatio = 999999999;
                Z090_DepthRatio = 999999999;
                Z095_DepthRatio = 999999999;
                Z100_DepthRatio = 999999999;
                
                D000_LossWidth = 999999999;
                D005_LossWidth = 999999999;
                D010_LossWidth = 999999999;
                D015_LossWidth = 999999999;
                D020_LossWidth = 999999999;
                D025_LossWidth = 999999999;
                D030_LossWidth = 999999999;
                D035_LossWidth = 999999999;
                D040_LossWidth = 999999999;
                D045_LossWidth = 999999999;
                D050_LossWidth = 999999999;
                D055_LossWidth = 999999999;
                D060_LossWidth = 999999999;
                D065_LossWidth = 999999999;
                D070_LossWidth = 999999999;
                D075_LossWidth = 999999999;
                D080_LossWidth = 999999999;
                D085_LossWidth = 999999999;
                D090_LossWidth = 999999999;
                D095_LossWidth = 999999999;
                D100_LossWidth = 999999999;
                disp('Measurement of osteointerface contains too few points.');
            end
            
        else
            %****Add catches for calculated variables here
            CartilageArea = 999999999;
            CartilageAreaLessOsteophyte = 999999999;
            TibialPlateauWidth_FromCartilageArea  = 999999999;
            AverageCartilageThickness_Pixels = 999999999;
            VariabilityInCartilageThickness_Pixels  = 999999999;
            MaximumCartilageThickness_Pixels = 999999999;
            MinimumCartilageThickness_Pixels = 999999999;
            LocationOfMaxCartilageThickness = 999999999;  %As Percentage of Medial Tibial Plateau Width
            LocationOfMinCartilageThickness = 999999999;  %As Percentage of Medial Tibial Plateau Width
            PercOfCartilageInTopBoundingBox = 999999999;  %In Other Words - CartilageLesion_ViaExtent
            PercOfCartilageInBottomBoundingBox = 999999999;  %In Other Words - SubchondralBoneOssification_ViaExtent
            
            Thickness_000 = 999999999;
            Thickness_005 = 999999999;
            Thickness_010 = 999999999;
            Thickness_015 = 999999999;
            Thickness_020 = 999999999;
            Thickness_025 = 999999999;
            Thickness_030 = 999999999;
            Thickness_035 = 999999999;
            Thickness_040 = 999999999;
            Thickness_045 = 999999999;
            Thickness_050 = 999999999;
            Thickness_055 = 999999999;
            Thickness_060 = 999999999;
            Thickness_065 = 999999999;
            Thickness_070 = 999999999;
            Thickness_075 = 999999999;
            Thickness_080 = 999999999;
            Thickness_085 = 999999999;
            Thickness_090 = 999999999;
            Thickness_095 = 999999999;
            Thickness_100 = 999999999;
                    
            TotalCartilageDamage = 999999999;
            Z1_CartilageDamage = 999999999;
            Z2_CartilageDamage = 999999999;
            Z3_CartilageDamage = 999999999;
            
            Z1_DepthRatio_Midpoint = 999999999;
            Z2_DepthRatio_Midpoint = 999999999;
            Z3_DepthRatio_Midpoint = 999999999;
            
            Z000_DepthRatio = 999999999;
            Z005_DepthRatio = 999999999;
            Z010_DepthRatio = 999999999;
            Z015_DepthRatio = 999999999;
            Z020_DepthRatio = 999999999;
            Z025_DepthRatio = 999999999;
            Z030_DepthRatio = 999999999;
            Z035_DepthRatio = 999999999;
            Z040_DepthRatio = 999999999;
            Z045_DepthRatio = 999999999;
            Z050_DepthRatio = 999999999;
            Z055_DepthRatio = 999999999;
            Z060_DepthRatio = 999999999;
            Z065_DepthRatio = 999999999;
            Z070_DepthRatio = 999999999;
            Z075_DepthRatio = 999999999;
            Z080_DepthRatio = 999999999;
            Z085_DepthRatio = 999999999;
            Z090_DepthRatio = 999999999;
            Z095_DepthRatio = 999999999;
            Z100_DepthRatio = 999999999;
            
            D000_LossWidth = 999999999;
            D005_LossWidth = 999999999;
            D010_LossWidth = 999999999;
            D015_LossWidth = 999999999;
            D020_LossWidth = 999999999;
            D025_LossWidth = 999999999;
            D030_LossWidth = 999999999;
            D035_LossWidth = 999999999;
            D040_LossWidth = 999999999;
            D045_LossWidth = 999999999;
            D050_LossWidth = 999999999;
            D055_LossWidth = 999999999;
            D060_LossWidth = 999999999;
            D065_LossWidth = 999999999;
            D070_LossWidth = 999999999;
            D075_LossWidth = 999999999;
            D080_LossWidth = 999999999;
            D085_LossWidth = 999999999;
            D090_LossWidth = 999999999;
            D095_LossWidth = 999999999;
            D100_LossWidth = 999999999;
            disp('Measurement of cartilage surface does not exist.');
        end
        
    else
        %****Add catches for calculated variables here
        CartilageArea = 999999999;
        CartilageAreaLessOsteophyte = 999999999;
        TibialPlateauWidth_FromCartilageArea  = 999999999;
        AverageCartilageThickness_Pixels = 999999999;
        VariabilityInCartilageThickness_Pixels  = 999999999;
        MaximumCartilageThickness_Pixels = 999999999;
        MinimumCartilageThickness_Pixels = 999999999;
        LocationOfMaxCartilageThickness = 999999999;  %As Percentage of Medial Tibial Plateau Width
        LocationOfMinCartilageThickness = 999999999;  %As Percentage of Medial Tibial Plateau Width
        PercOfCartilageInTopBoundingBox = 999999999;  %In Other Words - CartilageLesion_ViaExtent
        PercOfCartilageInBottomBoundingBox = 999999999;  %In Other Words - SubchondralBoneOssification_ViaExtent
        
        Thickness_000 = 999999999;
        Thickness_005 = 999999999;
        Thickness_010 = 999999999;
        Thickness_015 = 999999999;
        Thickness_020 = 999999999;
        Thickness_025 = 999999999;
        Thickness_030 = 999999999;
        Thickness_035 = 999999999;
        Thickness_040 = 999999999;
        Thickness_045 = 999999999;
        Thickness_050 = 999999999;
        Thickness_055 = 999999999;
        Thickness_060 = 999999999;
        Thickness_065 = 999999999;
        Thickness_070 = 999999999;
        Thickness_075 = 999999999;
        Thickness_080 = 999999999;
        Thickness_085 = 999999999;
        Thickness_090 = 999999999;
        Thickness_095 = 999999999;
        Thickness_100 = 999999999;
        
        TotalCartilageDamage = 999999999;
        Z1_CartilageDamage = 999999999;
        Z2_CartilageDamage = 999999999;
        Z3_CartilageDamage = 999999999;
        
        Z1_DepthRatio_Midpoint = 999999999;
        Z2_DepthRatio_Midpoint = 999999999;
        Z3_DepthRatio_Midpoint = 999999999;
        
        Z000_DepthRatio = 999999999;
        Z005_DepthRatio = 999999999;
        Z010_DepthRatio = 999999999;
        Z015_DepthRatio = 999999999;
        Z020_DepthRatio = 999999999;
        Z025_DepthRatio = 999999999;
        Z030_DepthRatio = 999999999;
        Z035_DepthRatio = 999999999;
        Z040_DepthRatio = 999999999;
        Z045_DepthRatio = 999999999;
        Z050_DepthRatio = 999999999;
        Z055_DepthRatio = 999999999;
        Z060_DepthRatio = 999999999;
        Z065_DepthRatio = 999999999;
        Z070_DepthRatio = 999999999;
        Z075_DepthRatio = 999999999;
        Z080_DepthRatio = 999999999;
        Z085_DepthRatio = 999999999;
        Z090_DepthRatio = 999999999;
        Z095_DepthRatio = 999999999;
        Z100_DepthRatio = 999999999;
        
        D000_LossWidth = 999999999;
        D005_LossWidth = 999999999;
        D010_LossWidth = 999999999;
        D015_LossWidth = 999999999;
        D020_LossWidth = 999999999;
        D025_LossWidth = 999999999;
        D030_LossWidth = 999999999;
        D035_LossWidth = 999999999;
        D040_LossWidth = 999999999;
        D045_LossWidth = 999999999;
        D050_LossWidth = 999999999;
        D055_LossWidth = 999999999;
        D060_LossWidth = 999999999;
        D065_LossWidth = 999999999;
        D070_LossWidth = 999999999;
        D075_LossWidth = 999999999;
        D080_LossWidth = 999999999;
        D085_LossWidth = 999999999;
        D090_LossWidth = 999999999;
        D095_LossWidth = 999999999;
        D100_LossWidth = 999999999;
        disp('Measurement of osteochondral interface does not exist.');
    end
   
    %% Measurement of Growth Plate Characteristics
    
    if isfield(rawpoints,'topofgrowthplate')

        if isfield(rawpoints,'bottomofgrowthplate')

            if length(rawpoints.topofgrowthplate(:,1)) > 2
                
                if length(rawpoints.bottomofgrowthplate(:,1)) > 2
                    
                    % Create outline of the growth plate cartilage --
                    LastGrowthPlatePoint_Top = rawpoints.topofgrowthplate(length(rawpoints.topofgrowthplate(:,1)),:);
                    FirstGrowthPlatePoint_Bottom = rawpoints.bottomofgrowthplate(1,:);
                    LastGrowthPlatePoint_Bottom = rawpoints.bottomofgrowthplate(length(rawpoints.bottomofgrowthplate(:,1)),:);
                    FirstPointDist = pdist([FirstGrowthPlatePoint_Bottom;LastGrowthPlatePoint_Top],'euclidean');
                    LastPointDist = pdist([LastGrowthPlatePoint_Bottom;LastGrowthPlatePoint_Top],'euclidean');
                    clear counter
                    if FirstPointDist < LastPointDist
                        GrowthPlate = [rawpoints.topofgrowthplate;rawpoints.bottomofgrowthplate;rawpoints.topofgrowthplate(1,:)];
                    else
                        counter = 1;
                        TopOfGrowthPlateLength = length(rawpoints.topofgrowthplate(:,1));
                        GrowthPlate = rawpoints.topofgrowthplate;
                        for i = length(rawpoints.bottomofgrowthplate(:,1)):-1:1
                            GrowthPlate(TopOfGrowthPlateLength+counter,:) = rawpoints.bottomofgrowthplate(i,:);
                            counter = counter+1;
                        end
                        GrowthPlate(TopOfGrowthPlateLength+counter,:) = rawpoints.topofgrowthplate(1,:);
                        clear counter
                    end
                    GrowthPlateArea = polyarea(GrowthPlate(:,1),GrowthPlate(:,2));
                    
                    GrowthPlate_n = ceil(max(GrowthPlate(:,1))); GrowthPlate_m = ceil(max(GrowthPlate(:,2))); %Do not clear n and m -- used later!
                    GrowthPlateBW_unrotated = poly2mask(GrowthPlate(:,1),GrowthPlate(:,2),GrowthPlate_m,GrowthPlate_n);
                    GrowthPlateBW_unrotated = ReduceToOneArea(GrowthPlateBW_unrotated);
                    GrowthPlateStats = regionprops(GrowthPlateBW_unrotated,'Orientation');
                    GrowthPlateBW = imrotate(GrowthPlateBW_unrotated,-GrowthPlateStats.Orientation);
                    
                    FindingGPStartAndEnd = sum(GrowthPlateBW);
                    GrowthPlateStart = min(find(FindingGPStartAndEnd > 0));
                    GrowthPlateEnd = max(find(FindingGPStartAndEnd > 0));
                    FindingGPTopAndBottom = sum(GrowthPlateBW');
                    GrowthPlateTop = min(find(FindingGPTopAndBottom > 0));
                    GrowthPlateBottom = max(find(FindingGPTopAndBottom > 0));
                    
                    GPWidth = GrowthPlateEnd - GrowthPlateStart;
                    InteriorGrowthPlateBW_Trimmed = GrowthPlateBW(GrowthPlateTop:GrowthPlateBottom,GrowthPlateStart:GrowthPlateStart+GPWidth/2);
                    OuterGrowthPlateBW_Trimmed = GrowthPlateBW(GrowthPlateTop:GrowthPlateBottom,GrowthPlateStart+GPWidth/2:GrowthPlateEnd);
                
                    OuterGrowthPlateBW_Trimmed = ReduceToOneArea(OuterGrowthPlateBW_Trimmed);
                    OuterGrowthPlateStats = regionprops(OuterGrowthPlateBW_Trimmed,'Orientation');
                    OuterGrowthPlateBW = imrotate(OuterGrowthPlateBW_Trimmed,-OuterGrowthPlateStats.Orientation);
                    
                    InteriorGrowthPlateBW_Trimmed = ReduceToOneArea(InteriorGrowthPlateBW_Trimmed);
                    InteriorGrowthPlateStats = regionprops(InteriorGrowthPlateBW_Trimmed,'Orientation');
                    InteriorGrowthPlateBW = imrotate(InteriorGrowthPlateBW_Trimmed,-InteriorGrowthPlateStats.Orientation);
                    
                    IGP = sum(InteriorGrowthPlateBW);
                    IGPStart = min(find(IGP > 0));
                    IGPEnd = max(find(IGP > 0));
                    InteriorGrowthPlateBW_Trimmed = InteriorGrowthPlateBW(:,IGPStart+(IGPEnd-IGPStart)*.1:IGPEnd-(IGPEnd-IGPStart)*.1);
                    
                    OGP = sum(OuterGrowthPlateBW);
                    OGPStart = min(find(OGP > 0));
                    OGPEnd = max(find(OGP > 0));
                    OuterGrowthPlateBW_Trimmed = OuterGrowthPlateBW(:,OGPStart+(OGPEnd-OGPStart)*.1:OGPEnd-(OGPEnd-OGPStart)*.1);
                    
                    InteriorGrowthPlateThickness = mean(sum(InteriorGrowthPlateBW_Trimmed));
                    OuterGrowthPlateThickness = mean(sum(OuterGrowthPlateBW_Trimmed));
                    
                else
                    
                    GrowthPlateArea = 999999999;
                    InteriorGrowthPlateThickness = 999999999;
                    OuterGrowthPlateThickness  = 999999999;
                    disp('Measurement of bottom of growth plate has too few points.');
                    
                end
                
            else
                
                GrowthPlateArea = 999999999;
                InteriorGrowthPlateThickness = 999999999;
                OuterGrowthPlateThickness  = 999999999;
                disp('Measurement of top of growth plate has too few points.');
                
            end
            
        else
            
            GrowthPlateArea = 999999999; InteriorGrowthPlateThickness = 999999999; OuterGrowthPlateThickness  = 999999999;
            disp('Measurement of bottom of growth plate does not exist.');
        
        end
        
    else
        
        GrowthPlateArea = 999999999; InteriorGrowthPlateThickness = 999999999; OuterGrowthPlateThickness  = 999999999;
        disp('Measurement of top of growth plate does not exist.');
        
    end
    
else
    
    TibialPlateauWidth = 999999999; TotalCartilageDegenerationWidth_Pixel = 999999999; TotalCartilageDegenerationWidth_Perc = 999999999;
    CartilageLossWidth_VisualMeasurement_Pixel = 999999999; CartilageLossWidth_VisualMeasurement_Perc = 999999999; MedialCapsuleWidth = 999999999;
    OsteophyteArea = 999999999; OsteophyteEccentricity = 999999999; OsteophyteOrientation  = 999999999; CartilageArea = 999999999;
    CartilageAreaLessOsteophyte = 999999999; TibialPlateauWidth_FromCartilageArea = 999999999; AverageCartilageThickness_Pixels = 999999999;
    VariabilityInCartilageThickness_Pixels = 999999999; MaximumCartilageThickness_Pixels = 999999999; MinimumCartilageThickness_Pixels = 999999999;
    LocationOfMaxCartilageThickness = 999999999; LocationOfMinCartilageThickness = 999999999; PercOfCartilageInTopBoundingBox = 999999999;
    PercOfCartilageInBottomBoundingBox = 999999999; Thickness_000 = 999999999; Thickness_005 = 999999999; Thickness_010 = 999999999;
    Thickness_015 = 999999999; Thickness_020 = 999999999; Thickness_025 = 999999999; Thickness_030 = 999999999; Thickness_035 = 999999999;
    Thickness_040 = 999999999; Thickness_045 = 999999999; Thickness_050 = 999999999; Thickness_055 = 999999999; Thickness_060 = 999999999;
    Thickness_065 = 999999999; Thickness_070 = 999999999; Thickness_075 = 999999999; Thickness_080 = 999999999; Thickness_085 = 999999999;
    Thickness_090 = 999999999; Thickness_095 = 999999999; Thickness_100 = 999999999; TotalCartilageDamage = 999999999; 
    Z1_CartilageDamage = 999999999; Z2_CartilageDamage = 999999999; Z3_CartilageDamage = 999999999; Z1_DepthRatio_Midpoint = 999999999; 
    Z2_DepthRatio_Midpoint = 999999999; Z3_DepthRatio_Midpoint = 999999999; Z000_DepthRatio = 999999999; Z005_DepthRatio = 999999999;
    Z010_DepthRatio = 999999999; Z015_DepthRatio = 999999999; Z020_DepthRatio = 999999999; Z025_DepthRatio = 999999999; Z030_DepthRatio = 999999999;
    Z035_DepthRatio = 999999999; Z040_DepthRatio = 999999999; Z045_DepthRatio = 999999999; Z050_DepthRatio = 999999999; Z055_DepthRatio = 999999999;
    Z060_DepthRatio = 999999999; Z065_DepthRatio = 999999999; Z070_DepthRatio = 999999999; Z075_DepthRatio = 999999999; Z080_DepthRatio = 999999999;
    Z085_DepthRatio = 999999999; Z090_DepthRatio = 999999999; Z095_DepthRatio = 999999999; Z100_DepthRatio = 999999999; D000_LossWidth = 999999999;
    D005_LossWidth = 999999999; D010_LossWidth = 999999999; D015_LossWidth = 999999999; D020_LossWidth = 999999999; D025_LossWidth = 999999999;
    D030_LossWidth = 999999999; D035_LossWidth = 999999999; D040_LossWidth = 999999999; D045_LossWidth = 999999999; D050_LossWidth = 999999999;
    D055_LossWidth = 999999999; D060_LossWidth = 999999999; D065_LossWidth = 999999999; D070_LossWidth = 999999999; D075_LossWidth = 999999999;
    D080_LossWidth = 999999999; D085_LossWidth = 999999999; D090_LossWidth = 999999999; D095_LossWidth = 999999999; D100_LossWidth = 999999999;
    GrowthPlateArea = 999999999; InteriorGrowthPlateThickness = 999999999; OuterGrowthPlateThickness  = 999999999;

    disp(['No Data Collected for ', filename,'. - Rawpoints Structure Does Not Exist.']);
    beep

end

DATA = [TibialPlateauWidth,TibialPlateauWidth_FromCartilageArea,TotalCartilageDegenerationWidth_Pixel,TotalCartilageDegenerationWidth_Perc,...
    CartilageLossWidth_VisualMeasurement_Pixel,CartilageLossWidth_VisualMeasurement_Perc,CartilageArea,CartilageAreaLessOsteophyte,...
    AverageCartilageThickness_Pixels,VariabilityInCartilageThickness_Pixels,MaximumCartilageThickness_Pixels,MinimumCartilageThickness_Pixels,...
    LocationOfMaxCartilageThickness,LocationOfMinCartilageThickness,PercOfCartilageInTopBoundingBox,PercOfCartilageInBottomBoundingBox,...
    TotalCartilageDamage,Z1_CartilageDamage,Z2_CartilageDamage,Z3_CartilageDamage,...
    Z1_DepthRatio_Midpoint,Z2_DepthRatio_Midpoint,Z3_DepthRatio_Midpoint,...
    MedialCapsuleWidth,OsteophyteArea,OsteophyteEccentricity,OsteophyteOrientation,...
    GrowthPlateArea,InteriorGrowthPlateThickness,OuterGrowthPlateThickness,...
    Thickness_000,Thickness_005,Thickness_010,Thickness_015,Thickness_020,Thickness_025,Thickness_030,Thickness_035,...
    Thickness_040,Thickness_045,Thickness_050,Thickness_055,Thickness_060,Thickness_065,Thickness_070,Thickness_075,...
    Thickness_080,Thickness_085,Thickness_090,Thickness_095,Thickness_100,...
    Z000_DepthRatio,Z005_DepthRatio,Z010_DepthRatio,Z015_DepthRatio,Z020_DepthRatio,Z025_DepthRatio,Z030_DepthRatio,Z035_DepthRatio,...
    Z040_DepthRatio,Z045_DepthRatio,Z050_DepthRatio,Z055_DepthRatio,Z060_DepthRatio,Z065_DepthRatio,Z070_DepthRatio,Z075_DepthRatio,...
    Z080_DepthRatio,Z085_DepthRatio,Z090_DepthRatio,Z095_DepthRatio,Z100_DepthRatio,...
    D000_LossWidth,D005_LossWidth,D010_LossWidth,D015_LossWidth,D020_LossWidth,D025_LossWidth,D030_LossWidth,D035_LossWidth,...
    D040_LossWidth,D045_LossWidth,D050_LossWidth,D055_LossWidth,D060_LossWidth,D065_LossWidth,D070_LossWidth,D075_LossWidth,...
    D080_LossWidth,D085_LossWidth,D090_LossWidth,D095_LossWidth,D100_LossWidth];

end


function im_out = ReduceToOneArea(im_in)

im_labeled = bwlabel(im_in);
Stats = regionprops(im_labeled,'Area');
ID = find([Stats.Area] == max([Stats.Area]));
im_labeled(im_labeled ~= ID) = 0;
im_out = im_labeled;

end

