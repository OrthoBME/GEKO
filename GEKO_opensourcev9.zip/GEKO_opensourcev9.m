function GEKO_opensourcev9

% GEKO is an automated GUI to evaluate knee OA in frontally sectioned
% rodent histological images. It calculates 8 of the 10 OARSI recommended
% grades from the OARSI histopathology initiative (Gerwin 2010).

%% FUNCTION NOTES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% lines can be set to 'hide' or 'show' to have lines appear as you draw them
% or to suppress the lines

% wfile is the file name for summary file, should include extension. IE 'GEKO_Summary.xls'

% getptsNoDoubleClick was provided at 
% https://cbi.nyu.edu/svn/mrTools/trunk/mrUtilities/MatlabUtilities/
% by the NYU CBI (info@cbi.nyu.edu)

%% EDIT LOG %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% BYMJ 6/15/17: Added back button and disabled getpts double-click to end
% selection. Fixed so that images may be selected from any folder (does not
% have to be in same location as GEKO function). Fixed file name finding
% for general case. Added try loop and error catching. Cleaned up comments.
% Added comments. Adjusted calculations to account for getpts change.

% BYMJ 6/16/17: Added dialogue box questions to set initial parameters and 
% remove all print to command line information to prep for .exe packaging.
% Added zoom functionality.

%%
% Turns off warnings for the session - BYMJ
warning('off','all')
warning

% Creates question dialogue box to set lines mode. Hide setting is selected
% as default. - BYMJ
choice = questdlg('Show or hide output lines during grading?', ...
	'Set Lines', ...
	'show','hide','hide');
% Handle response
switch choice
    case 'show'
        lines = 'show';
    case 'hide'
        lines = 'hide';
end

% Requests user set a summary file name. -BYMJ
prompt = {'Enter desired summary file name'};
dlg_title = 'Summary title';
num_lines = 1;
defaultans = {'GEKO_Summary'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
wfile = answer{1};

% Creates Headers for Output File
masterhist{1,1} = 'Sample ID';
masterhist{1,2} = 'Tibial Plateau Width (User Defined)';
masterhist{1,3} = 'Tibial Plateau Width (From Cartilage Area)';
masterhist{1,4} = 'Total Affected Cartilage Width (Pixels)';
masterhist{1,5} = 'Total Affected Cartilage Width (%)';
masterhist{1,6} = 'Cartilage Loss Width (User Defined, Pixels)';
masterhist{1,7} = 'Cartilage Loss Width (User Defined, %)';
masterhist{1,8} = 'Cartilage Area Including Osteophytes (Pixels)';
masterhist{1,9} = 'Cartilage Area Less Osteophytes (Pixels)';
masterhist{1,10} = 'Average Cartilage Thickness (Pixels)';
masterhist{1,11} = 'Variability In Cartilage Thickness (Variance, Pixels)';
masterhist{1,12} = 'Maximum Cartilage Thickness (Pixels)';
masterhist{1,13} = 'Minimum Cartilage Thickness (Pixels)';
masterhist{1,14} = 'Location of Maximum Cartilage Thickness (% of Tibial Plateau Width, 0 is central aspect of medial tibial plateau, 1 is medial margin)';
masterhist{1,15} = 'Location of Minimum Cartilage Thickness (% of Tibial Plateau Width, 0 is central aspect of medial tibial plateau, 1 is medial margin)';
masterhist{1,16} = 'Surface Cartilage Damage Measured Via Extent (Measure takes into account thickening of some cartilage and matrix loss [lesion] in other cartilage. The closer the value is to 1, the more rectangular the cartilage area is in shape.'; 
masterhist{1,17} = 'Hypertrophic Cartilage Ossification Measured Via Extent (Measure of calcification of deep cartilage. The closer the value is to 1, the flatter/straigth the osteochondral interface.';
masterhist{1,18} = 'Total Cartilage Damage (% Lesion Area Relative to Cartilage)';
masterhist{1,19} = 'Z1 Cartilage Damage (% Lesion Area Relative to Cartilage)';
masterhist{1,20} = 'Z2 Cartilage Damage (% Lesion Area Relative to Cartilage)';
masterhist{1,21} = 'Z3 Cartilage Damage (% Lesion Area Relative to Cartilage)';
masterhist{1,22} = 'Z1 Depth Ratio at Midpoint (%)';
masterhist{1,23} = 'Z2 Depth Ratio at Midpoint (%)';
masterhist{1,24} = 'Z3 Depth Ratio at Midpoint (%)';
masterhist{1,25} = 'Medial Joint Capsule Width (Pixels)';
masterhist{1,26} = 'Osteophyte Area (Pixels)';
masterhist{1,27} = 'Osteophyte Eccentricity (%, 0 is a circle, 1 is a line)';
masterhist{1,28} = 'Osteophyte Orientation (Degrees, Angle of the Main Osteophyte Axis Relative to the Cartilage)';
masterhist{1,29} = 'Growth Plate Area (Pixels)';
masterhist{1,30} = 'Growth Plate Thickness, Interior Half of Medial Tibial Plateau (Pixels)';
masterhist{1,31} = 'Growth Plate Thickness, Outer Half of Medial Tibial Plateau (Pixels)';
masterhist{1,32} = 'Thickness at 0% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,33} = 'Thickness at 5% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,34} = 'Thickness at 10% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,35} = 'Thickness at 15% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,36} = 'Thickness at 20% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,37} = 'Thickness at 25% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,38} = 'Thickness at 30% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,39} = 'Thickness at 35% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,40} = 'Thickness at 40% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,41} = 'Thickness at 45% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,42} = 'Thickness at 50% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,43} = 'Thickness at 55% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,44} = 'Thickness at 60% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,45} = 'Thickness at 65% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,46} = 'Thickness at 70% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,47} = 'Thickness at 75% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,48} = 'Thickness at 80% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,49} = 'Thickness at 85% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,50} = 'Thickness at 90% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,51} = 'Thickness at 95% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,52} = 'Thickness at 100% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,53} = 'Depth Ratio at 0% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,54} = 'Depth Ratio at 5% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,55} = 'Depth Ratio at 10% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,56} = 'Depth Ratio at 15% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,57} = 'Depth Ratio at 20% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,58} = 'Depth Ratio at 25% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,59} = 'Depth Ratio at 30% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,60} = 'Depth Ratio at 35% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,61} = 'Depth Ratio at 40% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,62} = 'Depth Ratio at 45% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,63} = 'Depth Ratio at 50% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,64} = 'Depth Ratio at 55% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,65} = 'Depth Ratio at 60% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,66} = 'Depth Ratio at 65% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,67} = 'Depth Ratio at 70% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,68} = 'Depth Ratio at 75% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,69} = 'Depth Ratio at 80% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,70} = 'Depth Ratio at 85% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,71} = 'Depth Ratio at 90% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,72} = 'Depth Ratio at 95% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,73} = 'Depth Ratio at 100% (Pixels, 0% if Middle of Joint, 100% is Medial Margin)';
masterhist{1,74} = 'Loss Ratio at 0% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,75} = 'Loss Ratio at 5% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,76} = 'Loss Ratio at 10% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,77} = 'Loss Ratio at 15% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,78} = 'Loss Ratio at 20% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,79} = 'Loss Ratio at 25% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,80} = 'Loss Ratio at 30% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,81} = 'Loss Ratio at 35% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,82} = 'Loss Ratio at 40% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,83} = 'Loss Ratio at 45% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,84} = 'Loss Ratio at 50% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,85} = 'Loss Ratio at 55% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,86} = 'Loss Ratio at 60% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,87} = 'Loss Ratio at 65% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,88} = 'Loss Ratio at 70% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,89} = 'Loss Ratio at 75% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,90} = 'Loss Ratio at 80% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,91} = 'Loss Ratio at 85% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,92} = 'Loss Ratio at 90% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,93} = 'Loss Ratio at 95% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';
masterhist{1,94} = 'Loss Ratio at 100% (Pixels, 0% if Cartilage Surface, 100% is Osteochondral Interface)';

% Give users instruction to select image files. -BYMJ
waitfor(msgbox({'Please select images to grade.' 'Use shift + left mouse to select more than one file.',...
    'Files may only be selected from one directory at a time.'},'Select Image Help'));

% Select image files to work with
[fname1,pname1]=uigetfile({'*.*';'*.jpg';'*.png';'*.tiff'},'Select Image(s)','MultiSelect', 'on');

% This is needed for the multiselect.  Always put the file in this format.
% -BYMJ
fname1 = cellstr(fname1); 

% Import Reference Images
OARSI1 = imread('OARSI1.png');
OARSI2 = imread('OARSI2.png');
OARSI3 = imread('OARSI3.png');
OARSI4 = imread('OARSI4.png');
OARSI5 = imread('OARSI5.png');
OARSI6 = imread('OARSI6.png');
OARSI7 = imread('OARSI7.png');
OARSI8 = imread('OARSI8.png');
OARSI9 = imread('OARSI9.png');
Lablogo = imread('Lablogo.jpg');

% Instructions for Error Coding
waitfor(msgbox({'An error log will be created in the MATLAB command Window.'...
    'Check this log before proceeding to data analysis.'...
    ' '...
    'Any variables that receive an error will appear as 999999999 in the'...
    'data sheet. Correct all errors prior to analyzing your data.'}));

% This for loop steps through each selected file. -BYMJ
for p = 1:length(fname1) % This for loop and everything before this line should be part of the GEKO shell code. -BYMJ
try % If a file crashes, continue on to the next file in "fname1". -BYMJ

    % Store current filename. -BYMJ
    filename = fullfile ( pname1, fname1{p} );
    % Break up filename into path, name, and extension.
    [~,name,~] = fileparts(filename);  
    
    % Read in the current file and set an identifier for the trial. -BYMJ
    I = imread(filename);
    ID = name;
    [r, c, ~] = size(I);   
    
    %% Create the marking points
    
    % Variable to indicate whether a regrade is needed. -BYMJ
    redo = 'y';
    while redo == 'y'      
        redo = 'n'; % Assume the image will not need to be regraded until the user inputs otherwise. -BYMJ -***Is this right? Won't the loop close immediately? KDA
        
        % Create the Main GUI figure. -BYMJ
        figure('units','normalized','outerposition',[0 0 1 1])
        hold on
        set(gcf,'Color','w');
        
        % Plot the reference image. -BYMJ
        subplot(3,4,1), image(OARSI1); axis off
        title('Reference Image')
        axis image 
        
        % Display the OrthoBME logo. -BYMJ
        subplot(3,4,9), image(Lablogo); axis off
        axis image
        subplot(3,4,[2:4,6:8,10:12]), image(I)
        ax = gca;
        title(ID,'interpreter','none')
        axis image
        
        linethick = 2;
           
        % Define tibial plateau
        clear px1 py1
               
        t1 = subplot(3,4,5, 'replace');
        fixfont = text(0,0,sprintf('Please click the \ntwo endpoints defining \nthe tibial plateau. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 16;
        
        [px1, py1] = getptsNoDoubleClick(ax);
        hold on       
        if exist('px1','var')
            subplot(3,4,[2:4,6:8,10:12]), plot(px1,py1,'ko');
        end
        
        rawpoints.tibplateau = [px1,py1];
                
        linecomp = strcmp(lines,'show');
        if linecomp == 1
            subplot(3,4,[2:4,6:8,10:12]), plat = plot(px1,py1,'k');
            set(plat,'LineWidth',linethick);
        end
        
        % Define joint capsule thickness  -- ***Should we up this? KDA
        clear sx1 sy1
        subplot(3,4,1), image(OARSI2), axis off
        title('Reference Image')
        axis image         
        
        t1 = subplot(3,4,5,'replace');
        fixfont = text(0,0,sprintf('Please trace a \nsection of the \njoint capsule. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 16;
        
        [sx1, sy1] = getptsNoDoubleClick(ax);
        hold on
        if exist('sx1','var')
            sxl = zeros(size(sx1,1),1);
            syl = zeros(size(sy1,1),1);
            for i = 1:size(sx1,1)
                sxl(i) = sx1(i);
                syl(i) = sy1(i);
            end
            subplot(3,4,[2:4,6:8,10:12]), plot(sx1,sy1,'go');
        end
        
        rawpoints.jointcapsule = [sx1,sy1];         
        
        linecomp = strcmp(lines,'show');
        if linecomp == 1
            subplot(3,4,[2:4,6:8,10:12]), plat = plot(sx1,sy1,'g');
            set(plat,'LineWidth',linethick);
        end
        
        % Define medial growth plate thickness 
        clear tgpx tgpy bgpx bgpy tgpx1 tgpy1 bgpx1 bgpy1
        subplot(3,4,1), image(OARSI3), axis off
        title('Reference Image')
        axis image  
        
        t1 = subplot(3,4,5,'replace');
        fixfont = text(0,0,sprintf('Please trace the \ntop of the medial \ngrowth plate. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 16;
        
        [tgpx1, tgpy1] = getptsNoDoubleClick(ax);
        hold on
        if exist('tgpx1','var')
            tgpx = zeros(size(tgpx1,1),1);
            tgpy = zeros(size(tgpy1,1),1);
            for i = 1:size(tgpx1,1)
                tgpx(i) = tgpx1(i);
                tgpy(i) = tgpy1(i);
            end
            subplot(3,4,[2:4,6:8,10:12]), plot(tgpx,tgpy,'mo');
        end
        
        rawpoints.topofgrowthplate = [tgpx,tgpy];
                
        linecomp = strcmp(lines,'show');
        if linecomp == 1
            subplot(3,4,[2:4,6:8,10:12]), tgp = plot(tgpx,tgpy,'m');
            set(tgp,'LineWidth',linethick);
        end     
        zoom out;
                
        subplot(3,4,1), image(OARSI4), axis off
        title('Reference Image')
        axis image    
        
        t1 = subplot(3,4,5,'replace');
        fixfont = text(0,0,sprintf('Please trace the \nbottom of the medial \ngrowth plate. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 16;
        
        [bgpx1, bgpy1] = getptsNoDoubleClick(ax);
        hold on
        if exist('bgpx1','var')
            bgpx = zeros(size(bgpx1,1),1);
            bgpy = zeros(size(bgpy1,1),1);
        for i = 1:size(bgpx1,1)
            bgpx(i) = bgpx1(i);
            bgpy(i) = bgpy1(i);
        end
            subplot(3,4,[2:4,6:8,10:12]), plot(bgpx,bgpy,'mo');
        end
        
        rawpoints.bottomofgrowthplate = [bgpx,bgpy]; 
        
        linecomp = strcmp(lines,'show');
        if linecomp == 1
            subplot(3,4,[2:4,6:8,10:12]), bgp = plot(bgpx,bgpy,'m');
            set(bgp,'LineWidth',linethick);
        end     
        zoom out;       
        
        %Trace osteochondral interface
        clear ocx ocy ocx1 ocy1
        subplot(3,4,1), image(OARSI5), axis off
        title('Reference Image')
        axis image
        
%         % Allows you to zoom in and out on the image. - BYMJ
%         t1 = subplot(3,4,5, 'replace');
%         fixfont = text(0,0,sprintf('Click and \ndrag an ROI \nto zoom in on \nif desired. \nEnter to continue.'),...
%             'Parent', t1); axis off
%         fixfont.FontSize = 16;
%         
%         zoom on;
%         pause() % you can zoom with your mouse and when your image is okay, you press any key. -BYMJ
%         zoom off; % to escape the zoom mode -BYMJ     
        
        t1 = subplot(3,4,5,'replace');
        fixfont = text(0,0,sprintf('Please trace the \nosteochondral interface. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 16;
        
        [ocx1, ocy1] = getptsNoDoubleClick(ax);
        hold on
        if exist('ocx1','var')
            ocx = zeros(size(ocx1,1),1);
            ocy = zeros(size(ocy1,1),1);
        for i = 1:size(ocx1,1)
            ocx(i) = ocx1(i);
            ocy(i) = ocy1(i);
        end
            subplot(3,4,[2:4,6:8,10:12]), plot(ocx,ocy,'yo');
        end
        
        rawpoints.osteointerface = [ocx,ocy]; 
        
        linecomp = strcmp(lines,'show');
        if linecomp == 1
            subplot(3,4,[2:4,6:8,10:12]), oc = plot(ocx,ocy,'y');
            set(oc,'LineWidth',linethick);
        end     
        zoom out;
        
        % Define total cartilage degeneration width
        clear tcdwx1 tcdwy1 
        subplot(3,4,1), image(OARSI6), axis off
        title('Reference Image')
        axis image

        t1 = subplot(3,4,5,'replace');
        fixfont = text(0,0,sprintf('If present, define the total \ncartilage degeneration \nwidth including proteoglycan \nloss. \n \nPress ENTER to end. \n \nIf not present, press \nENTER to skip.'), 'Parent', t1); axis off
        fixfont.FontSize = 16;
        
        [tcdwx1, tcdwy1] = getptsNoDoubleClick(ax);
        hold on
        if exist('tcdwx1','var')
            subplot(3,4,[2:4,6:8,10:12]), plot(tcdwx1,tcdwy1,'bo');
        end
        
        rawpoints.totalcartdegen = [tcdwx1,tcdwy1]; 
        
        linecomp = strcmp(lines,'show');
        if linecomp == 1
            if exist('tcdwx1','var')
                if size(tcdwx1)>0
                    subplot(3,4,[2:4,6:8,10:12]), tcdw = plot(tcdwx1,tcdwy1,'b:');
                    set(tcdw,'LineWidth',linethick);
                end
            end
        end
        
        % Define cartilage surface
        clear tcx tcy tcx1 tcy1
        subplot(3,4,1), image(OARSI7), axis off
        title('Reference Image')
        axis image
        
        t1 = subplot(3,4,5,'replace');
        fixfont = text(0,0,sprintf('Please trace the entire \ncartilage surface. \n \nPress ENTER to end.'), 'Parent', t1); axis off
        fixfont.FontSize = 16;
        
        [tcx1, tcy1] = getptsNoDoubleClick(ax);
        hold on
        if exist('tcx1','var')
            tcx = zeros(size(tcx1,1),1);
            tcy = zeros(size(tcy1,1),1);
        for i = 1:size(tcx1,1)
            tcx(i) = tcx1(i);
            tcy(i) = tcy1(i);
        end
            subplot(3,4,[2:4,6:8,10:12]), plot(tcx,tcy,'yo');
        end
        
        rawpoints.cartilagesurface = [tcx,tcy]; 
        
        linecomp = strcmp(lines,'show');
        if linecomp == 1
            subplot(3,4,[2:4,6:8,10:12]), tc = plot(tcx,tcy,'y');
            set(tc,'LineWidth',linethick);
        end     
        zoom out;
               
        % Define cartilage lesion width
        subplot(3,4,1), image(OARSI8), axis off
        title('Reference Image')
        axis image
        clear clwx clwy clwx1 clwy1

        t1 = subplot(3,4,5,'replace');
        fixfont = text(0,0,sprintf('If present, define the \ncartilage lesion width, \nwith a line connecting \nthe missing cartilage \nsurface.\n \nPress ENTER to end. \n \nIf not present, press \nENTER to skip.'), 'Parent', t1); axis off
        fixfont.FontSize = 16;
        
        [clwx1, clwy1] = getptsNoDoubleClick(ax);
        hold on
        if exist('clwx1','var')
            clwx = zeros(size(clwx1,1),1);
            clwy = zeros(size(clwy1,1),1);
        for i = 1:size(clwx1,1)
            clwx(i) = clwx1(i);
            clwy(i) = clwy1(i);
        end
            subplot(3,4,[2:4,6:8,10:12]), plot(clwx,clwy,'ro');
        end
        
        rawpoints.cartilagelesionwidth = [clwx,clwy]; 
        
        linecomp = strcmp(lines,'show');
        if linecomp == 1
            subplot(3,4,[2:4,6:8,10:12]), clw = plot(clwx,clwy,'r');
            set(clw,'LineWidth',linethick);
        end  
        
        % Define osteophyte
        subplot(3,4,1), image(OARSI9), axis off
        title('Reference Image')
        axis image
        clear ostx osty ostx1 osty1

        t1 = subplot(3,4,5,'replace');
        fixfont = text(0,0,sprintf('If present, trace \nthe osteophyte. \n \nPress ENTER to end. \n \nIf not present, press \nENTER to skip.'), 'Parent', t1); axis off
        fixfont.FontSize = 16;
        
        [ostx1, osty1] = getptsNoDoubleClick(ax);
        hold on
        if size(ostx1,1)>0
            ostx = zeros(size(ostx1,1),1);
            osty = zeros(size(osty1,1),1);
            for i = 1:size(ostx1,1)
                ostx(i) = ostx1(i);
                osty(i) = osty1(i);
            end
            subplot(3,4,[2:4,6:8,10:12]), plot(ostx,osty,'co');
        end
        
        rawpoints.osteophyte = [ostx1,osty1]; 
        
        linecomp = strcmp(lines,'show');
        if linecomp == 1
            if exist('ostx','var')
                subplot(3,4,[2:4,6:8,10:12]), fill(ostx,osty,'c');
            else
                subplot(3,4,[2:4,6:8,10:12]);
            end
        else
            subplot(3,4,[2:4,6:8,10:12]);
        end
        zoom out;
        
        % Plot all lines if the user wanted hidden lines during grading.
        linecomp = strcmp(lines,'show');
        if linecomp == 0
            hold on
            
            subplot(3,4,[2:4,6:8,10:12]), plat = plot(px1,py1,'k');
            set(plat,'LineWidth',linethick);            
            
            subplot(3,4,[2:4,6:8,10:12]), plat = plot(sx1,sy1,'g');
            set(plat,'LineWidth',linethick);            
            
            subplot(3,4,[2:4,6:8,10:12]), plat = plot(tgpx,tgpy,'m');
            set(plat,'LineWidth',linethick);
            
            subplot(3,4,[2:4,6:8,10:12]), plat = plot(bgpx,bgpy,'m:');
            set(plat,'LineWidth',linethick);            
            
            subplot(3,4,[2:4,6:8,10:12]), oc = plot(ocx,ocy,'y');
            set(oc,'LineWidth',linethick);            
            
            subplot(3,4,[2:4,6:8,10:12]), tc = plot(tcx,tcy,'y');
            set(tc,'LineWidth',linethick);
            
            if exist('clwx1','var')
                if size(clwx1)>0
                    subplot(3,4,[2:4,6:8,10:12]), plat = plot(clwx1,clwy1,'r');
                    set(plat,'LineWidth',linethick);
                end
            end            
            
            if exist('tcdwx1','var')
                if size(tcdwx1)>0
                    subplot(3,4,[2:4,6:8,10:12]), plat = plot(tcdwx1,tcdwy1,'b');
                    set(plat,'LineWidth',linethick);
                end
            end           
            
            if exist('ostx','var')
                if size(ostx)>0
                    subplot(3,4,[2:4,6:8,10:12]), plat = plot(ostx,osty,'c');
                    set(plat,'LineWidth',linethick);
                end
            end            
        end   
        
        
        %%%
        % Creates question dialogue box to regrade image. No is selected
        % as default. - BYMJ
        choice = questdlg('Would you like to regrade the image?', ...
            'Regrade', ...
            'yes','no','no');
        % Handle response
        switch choice
            case 'yes'
                redo = 'y';
                clear rawpoints
            case 'no'
                redo = 'n';
        end          
    end
    
    %% Begin processing collected data

    % Create a waitbar so user knows the code is running. -BYMJ
    wait = waitbar(0,'Processing data. Please wait.','WindowStyle','modal');
    
    % Save graded image.
    saveas(gcf,fullfile(pname1, [ID wfile '.png']), 'png'); 
    waitbar(.33); 
    
    % Save rawpoints structure and clear the variable. -BYMJ   
    save([ID wfile],'rawpoints');
    
    waitbar(.67);    
    
    %%%
    % This would be the place to move calculations into a separate function
    % that loads the necessary variables and processes and saves the data.
    % -BYMJ
    
    CalcOutput = GEKO_calc(rawpoints,filename);
    
    waitbar(1);
    close(wait); 
    
    close;
    
%     if length(fname1) == 1
%         break
%     end
    
catch
    
    if exist('wait','var') == 1
        close(wait);
    end
    waitfor(msgbox('ERROR encountered, continue to next image.','ERROR','WindowStyle','modal'))
    beep

end 

    clear rawpoints

    if exist('CalcOutput','var')
        GEKO_Output(p,:) = CalcOutput;
        masterhist{p+1,1} = ID; %'Sample ID';
        for qqq = 1:length(CalcOutput)
            masterhist{p+1,qqq+1} = CalcOutput(qqq);
        end
    
        save([wfile,'_backup'],'GEKO_Output');
        save([wfile,'_backup2'],'masterhist');
        xlswrite(wfile,masterhist);

        clear CalcOutput
    else
        masterhist{p+1,1} = ID; %'Sample ID';
        for qqq = 1:93
            masterhist{p+1,qqq+1} = 999999999;
        end
    
        save([wfile,'_backup2'],'masterhist');
        xlswrite(wfile,masterhist);
    end

    %% Old Heidi and MiRa Code
% %     % Does not try to save if the trial crashed.
% %     if exist('masterhist','var') == 1
% %         % Creates a dialogue box indicated excel sheet is saving. Indicates when
% %         % code is complete. -BYMJ
% %         d = msgbox('Saving data to excel file...','Save','WindowStyle','modal');
% %         set(findobj(d,'style','pushbutton'),'Visible','off')
% %         
% %         %% Create spreadsheets in standalone exe -BYMJ
% %         system('taskkill /F /IM EXCEL.EXE');
% %         if exist(fullfile(pname1,wfile),'file')
% %             data = xlsread(fullfile(pname1,wfile));
% %             system('taskkill /F /IM EXCEL.EXE');
% %             [dr, ~] = size(data);
% %             masterhist = table(masterhist(2:end,:));
% %             writetable(masterhist,fullfile(pname1,wfile),'Sheet',1,'Range',['A' num2str(dr+2)],'FileType','spreadsheet')
% %         else
% %             masterhist = table(masterhist);
% %             writetable(masterhist,fullfile(pname1,wfile),'Sheet',1,'Range','A1','FileType','spreadsheet')
% %         end
% % 
% %         set(findobj(d,'Tag','MessageBox'),'String','GEKO has finished.')
% %         set(findobj(d,'style','pushbutton'),'Visible','on')
% %         close all
% %     end

end

close all



function [x,y] = getptsNoDoubleClick(varargin)
%
% This is just a version of getpts that has the stuff that
% handles double clicking turned off because the system
% is so f*#$%ing slow that it thinks single clicks are double
% clicks. End selection by clicking right button. Comments that
% begin with jg show places where the function has been modified.
%
%GETPTS Select points with mouse.
%   [X,Y] = GETPTS(FIG) lets you choose a set of points in the
%   current axes of figure FIG using the mouse. Coordinates of
%   the selected points are returned in the vectors X and Y. Use
%   normal button clicks to add points.  A shift-, right-, or
%   double-click adds a final point and ends the selection.
%   Pressing RETURN or ENTER ends the selection without adding
%   a final point.  Pressing BACKSPACE or DELETE removes the
%   previously selected point.
%
%   [X,Y] = GETPTS(AX) lets you choose points in the axes
%   specified by the handle AX.
%
%   [X,Y] = GETPTS is the same as [X,Y] = GETPTS(GCF).
%
%   Example
%   --------
%       imshow('moon.tif')
%       [x,y] = getpts
%
%   See also GETRECT, GETLINE.

%   Callback syntaxes:
%       getpts('KeyPress')
%       getpts('FirstButtonDown')
%       getpts('NextButtonDown')

%   Copyright 1993-2004 The MathWorks, Inc.
%   $Revision$  $Date$

global GETPTS_FIG GETPTS_AX GETPTS_H1 GETPTS_H2
global GETPTS_PT1

if ((nargin >= 1) && (ischar(varargin{1})))
    % Callback invocation: 'KeyPress', 'FirstButtonDown', or
    % 'NextButtonDown'.
    feval(varargin{:});
    return;
end

% jg: tell user how to end this
% waitfor(msgbox('getptsNoDoubleClick',sprintf('(getptsNoDoubleClick) Hit enter to end selection')));

if (nargin < 1)
    GETPTS_AX = gca;
    GETPTS_FIG = ancestor(GETPTS_AX, 'figure');
else
    if (~ishandle(varargin{1}))
        eid = 'Images:getpts:expectedHandle';
        error(eid, '%s', 'First argument is not a valid handle');
    end
    
    switch get(varargin{1}, 'Type')
        case 'figure'
            GETPTS_FIG = varargin{1};
            GETPTS_AX = get(GETPTS_FIG, 'CurrentAxes');
            if (isempty(GETPTS_AX))
                GETPTS_AX = axes('Parent', GETPTS_FIG);
            end
            
        case 'axes'
            GETPTS_AX = varargin{1};
            GETPTS_FIG = ancestor(GETPTS_AX, 'figure');
            
        otherwise
            eid = 'Images:getpts:expectedFigureOrAxesHandle';
            error(eid, '%s', 'First argument should be a figure or axes handle');
            
    end
end

% Bring target figure forward
figure(GETPTS_FIG);

% Remember initial figure state
state = uisuspend(GETPTS_FIG);

% Set up initial callbacks for initial stage
[pointerShape, pointerHotSpot] = CreatePointer;
% jg:  change handles to call getptsNoDoubleClick
set(GETPTS_FIG, 'WindowButtonDownFcn', 'getptsNoDoubleClick(''FirstButtonDown'');', ...
    'KeyPressFcn', 'getptsNoDoubleClick(''KeyPress'');', ...
    'Pointer', 'custom', ...
    'PointerShapeCData', pointerShape, ...
    'PointerShapeHotSpot', pointerHotSpot);

% Initialize the lines to be used for the drag
markerSize = 9;
GETPTS_H1 = line('Parent', GETPTS_AX, ...
    'XData', [], ...
    'YData', [], ...
    'Visible', 'off', ...
    'Clipping', 'off', ...
    'Color', 'c', ...
    'LineStyle', 'none', ...
    'Marker', '+', ...
    'MarkerSize', markerSize, ...
    'EraseMode', 'xor');

GETPTS_H2 = line('Parent', GETPTS_AX, ...
    'XData', [], ...
    'YData', [], ...
    'Visible', 'off', ...
    'Clipping', 'off', ...
    'Color', 'm', ...
    'LineStyle', 'none', ...
    'Marker', 'x', ...
    'MarkerSize', markerSize, ...
    'EraseMode', 'xor');

% We're ready; wait for the user to do the drag
% Wrap the call to waitfor in try-catch so we'll
% have a chance to clean up after ourselves.
errCatch = 0;
try
    waitfor(GETPTS_H1, 'UserData', 'Completed');
catch
    errCatch=1;
end

% After the waitfor, if GETPTS_H1 is still valid
% and its UserData is 'Completed', then the user
% completed the drag.  If not, the user interrupted
% the action somehow, perhaps by a Ctrl-C in the
% command window or by closing the figure.

if (errCatch == 1)
    errStatus = 'trap';
    
elseif (~ishandle(GETPTS_H1) || ...
        ~strcmp(get(GETPTS_H1, 'UserData'), 'Completed'))
    errStatus = 'unknown';
    
else
    errStatus = 'ok';
    x = get(GETPTS_H1, 'XData');
    y = get(GETPTS_H1, 'YData');
    x = x(:);
    y = y(:);
    % If no points were selected, return rectangular empties.
    % This makes it easier to handle degenerate cases in
    % functions that call getpts.
    if (isempty(x))
        x = zeros(0,1);
    end
    if (isempty(y))
        y = zeros(0,1);
    end
end

% Delete the animation objects
if (ishandle(GETPTS_H1))
    delete(GETPTS_H1);
end
if (ishandle(GETPTS_H2))
    delete(GETPTS_H2);
end

% Restore the figure state
if (ishandle(GETPTS_FIG))
    uirestore(state);
end

% Clean up the global workspace
clear global GETPTS_FIG GETPTS_AX GETPTS_H1 GETPTS_H2
clear global GETPTS_PT1

% Depending on the error status, return the answer or generate
% an error message.
switch errStatus
    case 'ok'
        % No action needed.
        
    case 'trap'
        % An error was trapped during the waitfor
        eid = 'Images:getpts:interruptedMouseSelection';
        error(eid, '%s', 'Interruption during mouse point selection.');
        
    case 'unknown'
        % User did something to cause the point selection to
        % terminate abnormally.  For example, we would get here
        % if the user closed the figure in the middle of the selection.
        eid = 'Images:getpts:interruptedMouseSelection';
        error(eid, '%s', 'Interruption during mouse point selection.');
end


%--------------------------------------------------
% Subfunction KeyPress
%--------------------------------------------------
function KeyPress %#ok

global GETPTS_FIG GETPTS_AX GETPTS_H1 GETPTS_H2
global GETPTS_PT1

key = get(GETPTS_FIG, 'CurrentCharacter');
switch key
    case {char(8), char(127)}  % delete and backspace keys
        x = get(GETPTS_H1, 'XData');
        y = get(GETPTS_H1, 'YData');
        switch length(x)
            case 0
                % nothing to do
            case 1
                % remove point and start over
                set([GETPTS_H1 GETPTS_H2], ...
                    'XData', [], ...
                    'YData', []);
                % jg: call getptsNoDoubleClick
                set(GETPTS_FIG, 'WindowButtonDownFcn', ...
                    'getptsNoDoubleClick(''FirstButtonDown'');');
            otherwise
                % remove last point
                set([GETPTS_H1 GETPTS_H2], ...
                    'XData', x(1:end-1), ...
                    'YData', y(1:end-1));
        end
        
    case {char(13), char(3)}   % enter and return keys
        % return control to line after waitfor
        set(GETPTS_H1, 'UserData', 'Completed');
        
end

%--------------------------------------------------
% Subfunction FirstButtonDown
%--------------------------------------------------
function FirstButtonDown %#ok

global GETPTS_FIG GETPTS_AX GETPTS_H1 GETPTS_H2

[x,y] = getcurpt(GETPTS_AX);

set([GETPTS_H1 GETPTS_H2], ...
    'XData', x, ...
    'YData', y, ...
    'Visible', 'on');

% jg: never interpret double click
%if (~strcmp(get(GETPTS_FIG, 'SelectionType'), 'normal'))
% We're done!
%    set(GETPTS_H1, 'UserData', 'Completed');
%else
% jg: call getptsNoDoubleClick
set(GETPTS_FIG, 'WindowButtonDownFcn', 'getptsNoDoubleClick(''NextButtonDown'');');
%end

%--------------------------------------------------
% Subfunction NextButtonDown
%--------------------------------------------------
function NextButtonDown %#ok

global GETPTS_FIG GETPTS_AX GETPTS_H1 GETPTS_H2

% jg: always report that this is a single click
%selectionType = get(GETPTS_FIG, 'SelectionType');
selectionType = 'normal';

if (~strcmp(selectionType, 'open'))
    % We don't want to add a point on the second click
    % of a double-click
    
    [newx, newy] = getcurpt(GETPTS_AX);
    x = get(GETPTS_H1, 'XData');
    y = get(GETPTS_H2, 'YData');
    
    set([GETPTS_H1 GETPTS_H2], 'XData', [x newx], ...
        'YData', [y newy]);
    
end

% jg: never interpret double click
%if (~strcmp(get(GETPTS_FIG, 'SelectionType'), 'normal'))
% We're done!
%    set(GETPTS_H1, 'UserData', 'Completed');
%end



%----------------------------------------------------
% Subfunction CreatePointer
%----------------------------------------------------
function [pointerShape, pointerHotSpot] = CreatePointer

pointerHotSpot = [8 8];
pointerShape = [ ...
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    1   1   1   1   1   1   2 NaN   2   1   1   1   1   1   1   1
    2   2   2   2   2   2   2 NaN   2   2   2   2   2   2   2   2
    NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN
    2   2   2   2   2   2   2 NaN   2   2   2   2   2   2   2   2
    1   1   1   1   1   1   2 NaN   2   1   1   1   1   1   1   1
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    NaN NaN NaN NaN NaN   1   2 NaN   2   1 NaN NaN NaN NaN NaN NaN
    NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN NaN];


function [x,y] = getcurpt(axHandle)
%GETCURPT Get current point.
%   [X,Y] = GETCURPT(AXHANDLE) gets the x- and y-coordinates of
%   the current point of AXHANDLE.  GETCURPT compensates these
%   coordinates for the fact that get(gca,'CurrentPoint') returns
%   the data-space coordinates of the idealized left edge of the
%   screen pixel that the user clicked on.  For IPT functions, we
%   want the coordinates of the idealized center of the screen
%   pixel that the user clicked on.

%   Copyright 1993-2003 The MathWorks, Inc.
%   $Revision$  $Date$

pt = get(axHandle, 'CurrentPoint');
x = pt(1,1);
y = pt(1,2);











